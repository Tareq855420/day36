<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    protected $product;

    public function index()
    {
        return view('product.add');
    }

    public function js()
    {
        return view('js.js');
    }

    public function newProduct(Request $request)
    {
        Product::SaveData($request);
        return redirect()->back()->with('message', 'Product Created Successfully');
    }

    public function manageProduct()
    {
        return view ('product.manage', [
            'products' => Product::all(),
        ]);
    }

    public function deleteProduct($id)
    {
        $this->product = Product::findOrFail($id);
        if (file_exists($this->product->product_image))
        {
            unlink ($this->product->product_image);
        }

        $this->product->delete();
        return redirect()->back()->with('message', 'Product Deleted Successfully');
    }

    public function productStatus($id)
    {
        $this->product = Product::findOrFail($id);
        $this->product->status = $this->product->status == 1 ? 0: 1;
        $this->product->save();
        return redirect()->back()->with('message', 'Product Status Changed Successfully');
    }

    public function editProduct($id)
    {
        return view('product.edit', [
            'product' => Product::findOrFail($id),
        ]);
    }

    public function updateProduct(Request $request)
    {
        Product::updateData($request);
        return redirect('/manage-product')->with('message', 'Product Updated Successfully');
    }
}

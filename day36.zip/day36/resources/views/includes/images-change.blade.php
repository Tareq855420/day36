    <style>
        .small-image {
            height: 100px;
            width: 100px;
            cursor: pointer;
        }
    </style>

    <div class="ml-5" style="height: 400px; width: 600px;">
        <img src="{{ asset('assets/img/1.jpg') }}" alt="#" class="img-fluid h-100" id="mainImage">
    </div>
    <div class="ml-5 mt-2">
        <img src="{{ asset('assets/img/1.jpg') }}" alt="#" class="small-image mr-2" id="smallImage1">
        <img src="{{ asset('assets/img/2.jpg') }}" alt="#" class="small-image mr-2" id="smallImage2">
        <img src="{{ asset('assets/img/3.jpg') }}" alt="#" class="small-image mr-2" id="smallImage3">
        <img src="{{ asset('assets/img/4.jpg') }}" alt="#" class="small-image mr-2" id="smallImage4">
    </div>

    <script>
        var mainImage = document.getElementById('mainImage');
        var smallImage1 = document.getElementById('smallImage1');
        smallImage1.onclick = function () {
            var imgUrl = smallImage1.getAttribute('src');
            mainImage.setAttribute('src', imgUrl);
        }


        var smallImage2 = document.getElementById('smallImage2');
        smallImage2.onclick = function () {
            var imgUrl = smallImage2.getAttribute('src');
            mainImage.setAttribute('src', imgUrl);
        }


        var smallImage3 = document.getElementById('smallImage3');
        smallImage3.onclick = function () {
            var imgUrl = smallImage3.getAttribute('src');
            mainImage.setAttribute('src', imgUrl);
        }


        var smallImage4 = document.getElementById('smallImage4');
        smallImage4.onclick = function () {
            var imgUrl = smallImage4.getAttribute('src');
            mainImage.setAttribute('src', imgUrl);
        }
    </script>


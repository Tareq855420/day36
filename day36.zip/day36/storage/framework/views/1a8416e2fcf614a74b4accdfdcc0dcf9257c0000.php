<?php $__env->startSection('title'); ?>
    Manage Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Manage Product</h4>
                        </div>
                        <div class="card-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Product Name</th>
                                        <th>Product Category</th>
                                        <th>Brand Name</th>
                                        <th>Product Price</th>
                                        <th>Product Image</th>
                                        <th>Product Description</th>
                                        <th>Product Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($product->product_name); ?></td>
                                        <td><?php echo e($product->product_category); ?></td>
                                        <td><?php echo e($product->brand_name); ?></td>
                                        <td><?php echo e($product->product_price); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset($product->product_image)); ?>" style="height: 100px; width: 200px;" alt="">
                                        </td>
                                        <td><?php echo e($product->product_description); ?></td>
                                        <td><?php echo e($product->status == 1 ? 'Published' : 'Unpublished'); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('delete-product', ['id'=>$product->id])); ?>" class="btn btn-danger btn-sm">Del</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tareq\sixth_project\resources\views/product/manage.blade.php ENDPATH**/ ?>